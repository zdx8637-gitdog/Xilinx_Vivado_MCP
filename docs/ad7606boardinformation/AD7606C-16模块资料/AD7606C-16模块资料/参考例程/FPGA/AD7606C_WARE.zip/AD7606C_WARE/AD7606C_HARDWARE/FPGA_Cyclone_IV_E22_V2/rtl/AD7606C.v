module AD7606C(
  input   wire          SYS_CLK ,
  input   wire          SYS_RST ,
  inout   wire  [15:0]  DB0_15  ,
  input   wire          BUSY    ,
  input   wire          FRSTDATA,
  output  wire          SER_SEL ,
  output  wire          RESET   ,
  output  wire          CS      ,
  output  wire          RD_SCLK ,
  output  wire          WR      ,
  output  wire          CONVST  ,
  output  wire  [ 2:0]  OSC2_0  ,
  output  wire          STBY    
);

// 采样率设置
localparam SAMPLE_CLK_1MHz   = 20'd1_000_000 ;
localparam SAMPLE_CLK_500kHz = 20'd500_000   ;
localparam SAMPLE_CLK_200kHz = 20'd200_000   ;
localparam SAMPLE_CLK_100kHz = 20'd100_000   ;
localparam SAMPLE_CLK_50kHz  = 20'd50_000    ;
localparam SAMPLE_CLK_20kHz  = 20'd20_000    ;
localparam SAMPLE_CLK_10kHz  = 20'd10_000    ;
localparam SAMPLE_CLK_5kHz   = 20'd5_000     ;
localparam SAMPLE_CLK_2kHz   = 20'd2_000     ;
localparam SAMPLE_CLK_1kHz   = 20'd1_000     ;
localparam SAMPLE_CLK_500Hz  = 20'd500       ;
localparam SAMPLE_CLK_200Hz  = 20'd200       ;
localparam SAMPLE_CLK_100Hz  = 20'd100       ;

// 硬件模式并行
AD7606C_MODE0 #(
    .SAMPLE_CLK ( SAMPLE_CLK_1MHz )  // 采样率输入
)u_AD7606C_MODE0(  
    .SYS_CLK    ( SYS_CLK         ), // 主时钟信号
    .SYS_RST    ( SYS_RST         ), // FPGA复位信号
    .DB0_15     ( DB0_15          ), // 数据口
    .BUSY       ( BUSY            ), // 转换忙信号
    .FRSTDATA   ( FRSTDATA        ), // 第一个数据标志位
    .RESET      ( RESET           ), // 模块复位信号
    .CS         ( CS              ), // CS片选信号
    .RD_SCLK    ( RD_SCLK         ), // 读取时钟心寒
    .WR         ( WR              ), // 写入时钟信号
    .CONVST     ( CONVST          ), // 转化完成信号
    .SER_SEL    ( SER_SEL         ), // 串并行选择信号
    .OSC2_0     ( OSC2_0          ),
    .data_ch1   (                 ),
    .data_ch2   (                 ),
    .data_ch3   (                 ),
    .data_ch4   (                 ),
    .data_ch5   (                 ),
    .data_ch6   (                 ),
    .data_ch7   (                 ),
    .data_ch8   (                 ),
    .sample_out (                 )
);

assign STBY = 1'b1;

endmodule
