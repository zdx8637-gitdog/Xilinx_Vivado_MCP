module AD7606C_MODE0 #(
    parameter SAMPLE_CLK = 20'd1_000_000
)(  // 硬件模式
    input   wire          SYS_CLK  ,
    input   wire          SYS_RST  ,
    input   wire  [15:0]  DB0_15   ,
    input   wire          BUSY     ,
    input   wire          FRSTDATA ,
    output  wire          RESET    ,
    output  wire          CS       ,
    output  wire          RD_SCLK  ,
    output  wire          WR       ,
    output  wire          CONVST   ,
    output  wire          SER_SEL  ,
    output  wire  [ 2:0]  OSC2_0   ,
    output  wire  [15:0]  data_ch1 ,
    output  wire  [15:0]  data_ch2 ,
    output  wire  [15:0]  data_ch3 ,
    output  wire  [15:0]  data_ch4 ,
    output  wire  [15:0]  data_ch5 ,
    output  wire  [15:0]  data_ch6 ,
    output  wire  [15:0]  data_ch7 ,
    output  wire  [15:0]  data_ch8 ,
    output  wire          sample_out
);

localparam delay_100ms = ( 50_000_000 / 10  ) - 1;
localparam delay_50ms  = ( 50_000_000 / 20  ) - 1;
localparam delay_10ms  = ( 50_000_000 / 100 ) - 1;
localparam CYCLE_CNT   = ( 2 * 8 ) - 1;
localparam SAMPLE_CNT  = (50_000_000 / SAMPLE_CLK) - 1;

reg [2:0]  STATE  ;
reg [23:0] delay_cnt;
reg [3:0]  DATA_SEL;
reg        cs     ;
reg        rd_sclk;
reg        reset  ;
reg        convst ;
reg [15:0] ch1_data;
reg [15:0] ch2_data;
reg [15:0] ch3_data;
reg [15:0] ch4_data;
reg [15:0] ch5_data;
reg [15:0] ch6_data;
reg [15:0] ch7_data;
reg [15:0] ch8_data;

reg        rd_reg  ;
wire       rd_nege ;

reg        busy1;
reg        busy2;
wire       busy_nege;

reg          sample_sig;
reg  [19:0]  sample_cnt;

reg          firstdata_r;

always@( posedge SYS_CLK or negedge SYS_RST )
begin
    if( !SYS_RST )begin
       firstdata_r <= 1'b0;
    end
    else begin
       firstdata_r <= FRSTDATA;
    end
end

always@(posedge SYS_CLK or negedge SYS_RST)
begin
    if(!SYS_RST)begin
        sample_sig <= 1'b0;
        sample_cnt <= 20'd0;
    end
    else if(sample_cnt == SAMPLE_CNT)begin
        if(STATE == 3'd5)begin
            sample_sig <= 1'b1;
            sample_cnt <= 20'd0;
        end
        else begin
            sample_sig <= 1'b0;
            sample_cnt <= sample_cnt;
        end
    end
    else begin
        sample_sig <= 1'b0;
        sample_cnt <= sample_cnt + 1'b1;
    end
end

always@(posedge SYS_CLK or negedge SYS_RST)
begin
    if(!SYS_RST)begin
        busy1 <= 1'b0;
        busy2 <= 1'b0;
    end
    else begin
        busy1 <= BUSY ;
        busy2 <= busy1;
    end
end

assign busy_nege = (~busy1) & busy2;

always@(posedge SYS_CLK or negedge SYS_RST)
begin  
    if(!SYS_RST)begin
        cs      <= 1'b1;
        rd_sclk <= 1'b1;
        reset   <= 1'b0;
        convst  <= 1'b0;
        delay_cnt <= 24'd0;
        STATE   <= 3'd0;
    end
    else begin
        case(STATE)
            3'd0:begin  // 初始化100MS
                cs      <= 1'b1;
                rd_sclk <= 1'b1;
                reset   <= 1'b0;
                convst  <= 1'b0;
                if(delay_cnt >= delay_100ms)begin
                    delay_cnt <= 24'd0;
                    STATE <= 3'd1;
                end
                else begin
                    delay_cnt <= delay_cnt + 1'b1;
                    STATE <= 3'd0;
                end
            end
            3'd1:begin  // 系统复位
                if(delay_cnt >= delay_100ms)begin
                    delay_cnt <= 24'd0;
                    STATE <= 3'd2;
                end
                else if(delay_cnt >= delay_10ms)begin
                    reset <= 1'b0;
                    delay_cnt <= delay_cnt + 1'b1;
                    STATE <= 3'd1;
                end
                else begin
                    reset <= 1'b1;
                    delay_cnt <= delay_cnt + 1'b1;
                    STATE <= 3'd1;
                end
            end
            3'd2:begin
                convst <= 1'b0;
                STATE  <= 3'd3;
            end
            3'd3:begin
                convst <= 1'b1;
                cs <= busy_nege ? 1'b0 : 1'b1;
                STATE <= busy_nege ? 3'd4 : 3'd3;
            end
            3'd4:begin
                rd_sclk <= ~rd_sclk;
                if(delay_cnt == CYCLE_CNT)begin
                    delay_cnt <= 24'd0;
                    STATE <= 3'd5;
                end
                else begin
                    delay_cnt <= delay_cnt + 1'b1;
                    STATE <= 3'd4;
                end
            end
            3'd5:begin
                cs <= 1'b1;
                rd_sclk <= 1'b1;
                convst  <= 1'b0;
                STATE   <= sample_sig ? 3'd3 : 3'd5;
            end
            default:STATE <= 3'd0;
        endcase
    end
end

always@(posedge SYS_CLK or negedge SYS_RST)
begin
    if(!SYS_RST)begin
        rd_reg <= 1'b0;
    end
    else begin
        rd_reg <= rd_sclk;
    end
end

assign rd_nege = (~rd_sclk) & rd_reg;

always@(posedge SYS_CLK or negedge SYS_RST)
begin
    if(!SYS_RST)begin
        DATA_SEL <= 3'd0;
        ch1_data <= 16'd0;
        ch2_data <= 16'd0;
        ch3_data <= 16'd0;
        ch4_data <= 16'd0;
        ch5_data <= 16'd0;
        ch6_data <= 16'd0;
        ch7_data <= 16'd0;
        ch8_data <= 16'd0;
    end
    else if(rd_nege == 1'b1)begin
        case(DATA_SEL)
            3'd0:begin
                ch1_data <= firstdata_r ? DB0_15 : 16'd0;
                DATA_SEL <= firstdata_r ? 3'd1 : 3'd0;;
            end
            3'd1:begin
                ch2_data <= DB0_15;
                DATA_SEL <= 3'd2;
            end
            3'd2:begin
                ch3_data <= DB0_15;
                DATA_SEL <= 3'd3;
            end
            3'd3:begin
                ch4_data <= DB0_15;
                DATA_SEL <= 3'd4;
            end
            3'd4:begin
                ch5_data <= DB0_15;
                DATA_SEL <= 3'd5;
            end
            3'd5:begin
                ch6_data <= DB0_15;
                DATA_SEL <= 3'd6;
            end
            3'd6:begin
                ch7_data <= DB0_15;
                DATA_SEL <= 3'd7;
            end
            3'd7:begin
                ch8_data <= DB0_15;
                DATA_SEL <= 3'd0;
            end
            default:DATA_SEL <= 3'd0;
        endcase
    end
    else begin
        ch1_data <= ch1_data;
        ch2_data <= ch2_data;
        ch3_data <= ch3_data;
        ch4_data <= ch4_data;
        ch5_data <= ch5_data;
        ch6_data <= ch6_data;
        ch7_data <= ch7_data;
        ch8_data <= ch8_data;
    end
end


assign data_ch1 = ch1_data ;
assign data_ch2 = ch2_data ;
assign data_ch3 = ch3_data ;
assign data_ch4 = ch4_data ;
assign data_ch5 = ch5_data ;
assign data_ch6 = ch6_data ;
assign data_ch7 = ch7_data ;
assign data_ch8 = ch8_data ;

assign sample_out = sample_sig;
assign RESET   = reset;
assign CS      = cs;
assign RD_SCLK = rd_sclk;
assign WR      = 1'b0;
assign CONVST  = convst;
assign OSC2_0  = 3'b000;  // 000 -> 硬件模式 ， 111 -> 软件模式
assign SER_SEL = 1'b0  ;  // 1 -> 串行模式 ， 0 -> 并行模式

endmodule
